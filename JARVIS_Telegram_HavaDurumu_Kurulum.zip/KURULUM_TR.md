# J.A.R.V.I.S. — Her sabah Telegram hava durumu bildirimi

Bu paket, GitHub Actions ile her gün yaklaşık Türkiye saati 08:00'de İzmir hava durumunu kontrol eder ve Telegram mesajı gönderir. GitHub zamanlanmış işleri bazen geciktirebilir; tam dakikada çalışacağı garanti değildir.

## 1) Telegram botu oluştur
1. Telegram'da **@BotFather** hesabını aç.
2. `/newbot` yaz ve bot için ad ile kullanıcı adı belirle.
3. BotFather'ın verdiği bot token'ını kimseyle paylaşma.
4. Kendi botunu açıp **Start / Başlat** düğmesine bas.

## 2) Chat ID'ni öğren
1. Botuna Telegram'da bir mesaj gönder (ör. `Merhaba`).
2. Tarayıcıda şu adresi aç; `BOT_TOKEN` kısmına kendi token'ını koy:
   `https://api.telegram.org/botBOT_TOKEN/getUpdates`
3. Gelen JSON içindeki `message` → `chat` → `id` değerini bul. Bu senin `TELEGRAM_CHAT_ID` değerindir.
4. Bot token'ını veya bu adresin ekran görüntüsünü başkalarıyla paylaşma.

## 3) GitHub deposu oluştur
1. GitHub'da yeni bir repository oluştur (ör. `jarvis-hava-durumu`).
2. Bu ZIP içindeki dosyaları ve `.github` klasörünü depoya yükle. Klasör yapısı şöyle olmalı:
   - `.github/workflows/weather.yml`
   - `weather.py`
   - `KURULUM_TR.md`

## 4) Gizli bilgileri GitHub'a ekle
Depoda **Settings → Secrets and variables → Actions → New repository secret** yolunu aç ve iki secret ekle:
- `TELEGRAM_BOT_TOKEN` = BotFather token'ı
- `TELEGRAM_CHAT_ID` = chat ID sayısı

Token'ı kodun içine yazma ve herkese açık dosyalara koyma.

## 5) İlk denemeyi yap
1. Depoda **Actions** sekmesine gir.
2. **JARVIS Sabah Hava Durumu** iş akışını seç.
3. **Run workflow** düğmesiyle elle çalıştır.
4. Telegram'dan mesaj geldiyse kurulum çalışıyor demektir. Sonrasında zamanlanmış çalışma her gün yaklaşık 08:00 Türkiye saatinde gerçekleşir.

## Notlar
- Hava verisi Open-Meteo'dan alınır; API anahtarı gerektirmez.
- Bu sistem HTML dosyandan bağımsız çalışır. HTML'nin açık kalması gerekmez.
- Bu paket yalnızca İzmir merkez içindir. Başka şehir istersen `weather.py` içindeki koordinatları değiştir.
- GitHub Actions zamanlanmış görevleri yoğunluk nedeniyle gecikebilir. İlk çalıştırmayı elle test et.
