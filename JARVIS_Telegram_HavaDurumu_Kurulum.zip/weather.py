import json
import os
import urllib.parse
import urllib.request
from datetime import datetime
from zoneinfo import ZoneInfo

BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "").strip()

if not BOT_TOKEN or not CHAT_ID:
    raise SystemExit(
        "Eksik GitHub Secrets: TELEGRAM_BOT_TOKEN ve TELEGRAM_CHAT_ID eklenmeli."
    )

# İzmir merkez koordinatları
latitude, longitude = 38.4237, 27.1428
url = (
    "https://api.open-meteo.com/v1/forecast"
    f"?latitude={latitude}&longitude={longitude}"
    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,"
    "precipitation,weather_code,wind_speed_10m"
    "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,"
    "weather_code"
    "&forecast_days=1&timezone=Europe%2FIstanbul"
)

def get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "JARVIS-Weather-Bot/1.0"})
    with urllib.request.urlopen(req, timeout=25) as response:
        return json.loads(response.read().decode("utf-8"))

data = get_json(url)
current = data["current"]
daily = data["daily"]
temp = round(current["temperature_2m"])
feels = round(current["apparent_temperature"])
humidity = current["relative_humidity_2m"]
wind = round(current["wind_speed_10m"])
low = round(daily["temperature_2m_min"][0])
high = round(daily["temperature_2m_max"][0])
rain_chance = daily["precipitation_probability_max"][0]
code = daily["weather_code"][0]

descriptions = {
    0: "Açık", 1: "Çoğunlukla açık", 2: "Parçalı bulutlu", 3: "Kapalı",
    45: "Sisli", 48: "Kırağılı sis",
    51: "Hafif çisenti", 53: "Çisenti", 55: "Yoğun çisenti",
    61: "Hafif yağmur", 63: "Yağmur", 65: "Kuvvetli yağmur",
    71: "Hafif kar", 73: "Kar", 75: "Yoğun kar", 80: "Hafif sağanak",
    81: "Sağanak", 82: "Kuvvetli sağanak", 95: "Gök gürültülü fırtına",
    96: "Dolu ihtimalli fırtına", 99: "Kuvvetli dolu ihtimalli fırtına",
}
description = descriptions.get(code, "Değişken hava")

now = datetime.now(ZoneInfo("Europe/Istanbul"))
message = (
    f"🤖 Günaydın! J.A.R.V.I.S. hava raporu — İzmir\n"
    f"📅 {now:%d.%m.%Y}\n\n"
    f"🌤️ Durum: {description}\n"
    f"🌡️ Şu an: {temp}°C (hissedilen {feels}°C)\n"
    f"📉 Günün en düşüğü: {low}°C\n"
    f"📈 Günün en yükseği: {high}°C\n"
    f"💧 Nem: %{humidity}\n"
    f"💨 Rüzgâr: {wind} km/sa\n"
    f"🌧️ Günlük yağış ihtimali: %{rain_chance if rain_chance is not None else 'bilinmiyor'}"
)
if rain_chance is not None and rain_chance >= 50:
    message += "\n\n☔ UYARI: Bugün yağmur ihtimali yüksek, şemsiyeni al!"
elif code in (61, 63, 65, 80, 81, 82, 95, 96, 99):
    message += "\n\n☔ Yağış bekleniyor; dışarı çıkarken hazırlıklı ol."

api_url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
payload = urllib.parse.urlencode({"chat_id": CHAT_ID, "text": message}).encode()
req = urllib.request.Request(api_url, data=payload, method="POST")
with urllib.request.urlopen(req, timeout=25) as response:
    result = json.loads(response.read().decode("utf-8"))
if not result.get("ok"):
    raise SystemExit("Telegram mesajı gönderilemedi: " + str(result))
print("Hava durumu Telegram'a gönderildi.")
